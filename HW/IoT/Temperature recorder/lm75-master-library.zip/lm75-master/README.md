# lm75
Arduino library for access to LM75 temperature sensor
